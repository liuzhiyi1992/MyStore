//
//  JSONModelerTests.h
//  JSONModelerTests
//
//  Created by Jon Rexeisen on 11/3/11.
//  Copyright (c) 2011 Nerdery Interactive Labs. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface JSONModelerTests : SenTestCase

@end
