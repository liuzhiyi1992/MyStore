//
//  EditPropertyViewController.h
//  JSONModeler
//
//  Created by Jon Rexeisen on 12/1/11.
//  Copyright (c) 2011 Nerdery Interactive Labs. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class ClassPropertiesObject;

@interface EditPropertyViewController : NSViewController

@property (retain) ClassPropertiesObject *propertiesObject;

@end
